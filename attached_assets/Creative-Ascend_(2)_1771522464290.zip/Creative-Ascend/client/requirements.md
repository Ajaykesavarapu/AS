## Packages
framer-motion | Essential for 3D animations, parallax effects, and smooth transitions
react-intersection-observer | For triggering animations when elements come into view
clsx | Utility for conditional class names (standard with tailwind-merge)
tailwind-merge | Utility for merging tailwind classes (standard)
lucide-react | Icons (already in base, but listing for completeness)

## Notes
The application requires a strong 3D aesthetic. We will use Framer Motion heavily for scroll-triggered animations and 3D transforms.
Images should be high-quality and evocative of 3D space.
The "Let's Talk" button will trigger a contact modal or scroll to a contact section.
Services require a dedicated detail page `/services/:slug`.
