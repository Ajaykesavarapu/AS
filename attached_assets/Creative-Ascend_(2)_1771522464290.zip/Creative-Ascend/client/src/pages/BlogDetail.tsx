import { useParams, Link } from "wouter";
import { useBlog } from "@/hooks/use-blogs";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { ArrowLeft, User, Calendar } from "lucide-react";

export default function BlogDetail() {
  const { slug } = useParams();
  const { data: blog, isLoading } = useBlog(slug || "");

  if (isLoading) {
    return <div className="min-h-screen bg-background flex items-center justify-center text-white">Loading...</div>;
  }

  if (!blog) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center text-white">
        <h1 className="text-4xl font-bold mb-4">Post Not Found</h1>
        <Link href="/blogs" className="text-primary hover:underline">Back to Blogs</Link>
      </div>
    );
  }

  return (
    <div className="bg-background min-h-screen text-white">
      <Navbar />
      
      <article className="pt-32 pb-20 container mx-auto px-4 max-w-4xl">
        <Link href="/blogs" className="inline-flex items-center text-muted-foreground hover:text-white mb-8 transition-colors">
          <ArrowLeft className="mr-2 w-4 h-4" /> Back to Insights
        </Link>
        
        <header className="mb-12 text-center">
          <h1 className="font-display text-4xl md:text-6xl font-bold mb-6 leading-tight">{blog.title}</h1>
          
          <div className="flex items-center justify-center gap-6 text-muted-foreground">
            <div className="flex items-center gap-2">
              <User size={16} />
              <span>{blog.author}</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar size={16} />
              <span>{new Date(blog.publishedAt || Date.now()).toLocaleDateString()}</span>
            </div>
          </div>
        </header>

        {blog.coverImage && (
          <div className="rounded-[2rem] overflow-hidden mb-12 border border-white/10 shadow-2xl">
            <img src={blog.coverImage} alt={blog.title} className="w-full h-auto object-cover" />
          </div>
        )}

        <div className="prose prose-invert prose-lg max-w-none">
          <div className="whitespace-pre-wrap leading-relaxed text-white/80">
            {blog.content}
          </div>
        </div>
      </article>
      
      <Footer />
    </div>
  );
}
