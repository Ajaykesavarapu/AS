import { useParams, Link } from "wouter";
import { useService } from "@/hooks/use-services";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { motion } from "framer-motion";
import { CheckCircle2, ArrowLeft, ArrowRight } from "lucide-react";

export default function ServiceDetail() {
  const { slug } = useParams();
  const { data: service, isLoading } = useService(slug || "");

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!service) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center text-white">
        <h1 className="text-4xl font-bold mb-4">Service Not Found</h1>
        <Link href="/services" className="text-primary hover:underline">Back to Services</Link>
      </div>
    );
  }

  // Parse JSON fields if they come as strings, or use directly if already parsed
  const keyBenefits = Array.isArray(service.keyBenefits) 
    ? service.keyBenefits 
    : JSON.parse(service.keyBenefits as unknown as string || "[]");
    
  const useCases = Array.isArray(service.useCases)
    ? service.useCases
    : JSON.parse(service.useCases as unknown as string || "[]");

  return (
    <div className="bg-background min-h-screen text-white overflow-x-hidden">
      <Navbar />
      
      {/* Hero Section */}
      <header className="relative pt-40 pb-20 px-4 md:px-8 overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/20 rounded-full blur-[120px] pointer-events-none" />
        
        <div className="container mx-auto max-w-6xl relative z-10">
          <Link href="/services" className="inline-flex items-center text-muted-foreground hover:text-white mb-8 transition-colors">
            <ArrowLeft className="mr-2 w-4 h-4" /> Back to Services
          </Link>
          
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-display text-5xl md:text-7xl font-bold mb-8 leading-tight"
          >
            {service.title}
          </motion.h1>
          
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-xl md:text-2xl text-muted-foreground max-w-3xl leading-relaxed border-l-4 border-primary pl-6"
          >
            {service.fullDescription}
          </motion.div>
        </div>
      </header>

      {/* Why This? */}
      <section className="py-20 bg-white/5 backdrop-blur-sm border-y border-white/5">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-display font-bold mb-6">Why Choose This?</h2>
              <div className="w-20 h-1 bg-primary mb-8" />
              <p className="text-lg text-muted-foreground leading-loose">
                {service.whyThis}
              </p>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative aspect-square rounded-[3rem] overflow-hidden border border-white/10 shadow-2xl"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20 animate-pulse" />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="font-display text-9xl font-bold text-white/10 select-none">3D</span>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Key Benefits */}
      <section className="py-24 container mx-auto px-4 max-w-6xl">
        <h2 className="text-4xl md:text-5xl font-display font-bold mb-16 text-center">Key Benefits</h2>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {keyBenefits.map((benefit: string, index: number) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
              className="glass-card p-8 rounded-2xl hover:border-primary/50 transition-colors group"
            >
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mb-6 text-primary group-hover:scale-110 transition-transform">
                <CheckCircle2 size={24} />
              </div>
              <h3 className="text-xl font-bold mb-3">{benefit}</h3>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Use Cases Carousel */}
      <section className="py-24 bg-gradient-to-r from-primary/5 via-background to-secondary/5 border-y border-white/5">
        <div className="container mx-auto px-4 max-w-6xl">
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-16">Real-World Applications</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            {useCases.map((useCase: string, index: number) => (
              <motion.div
                key={index}
                whileHover={{ scale: 1.02 }}
                className="bg-black/40 p-8 rounded-3xl border border-white/10 hover:border-white/30 transition-all cursor-default"
              >
                <div className="flex items-start gap-4">
                  <span className="font-display text-4xl font-bold text-white/10">0{index + 1}</span>
                  <p className="text-lg text-white/90 pt-2">{useCase}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Approach */}
      <section className="py-24 container mx-auto px-4 max-w-6xl">
        <div className="bg-white/5 rounded-[3rem] p-8 md:p-16 border border-white/10 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent pointer-events-none" />
          
          <div className="relative z-10 text-center max-w-3xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-display font-bold mb-8">Our Approach</h2>
            <p className="text-xl text-muted-foreground leading-relaxed">
              {service.ourApproach}
            </p>
            
            <div className="mt-12">
              <Link href="/contact">
                <button className="px-10 py-4 rounded-xl bg-gradient-to-r from-primary to-secondary text-white font-bold text-lg shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/40 hover:-translate-y-1 transition-all">
                  Get Started with {service.title} <ArrowRight className="inline ml-2" />
                </button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
