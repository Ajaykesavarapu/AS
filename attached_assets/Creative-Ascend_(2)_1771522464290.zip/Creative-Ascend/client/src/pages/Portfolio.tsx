import { motion } from "framer-motion";
import { usePortfolio } from "@/hooks/use-portfolio";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { ExternalLink } from "lucide-react";

export default function Portfolio() {
  const { data: portfolio } = usePortfolio();
  
  // Fake data for visual if empty
  const items = portfolio?.length ? portfolio : [
    { id: 1, title: "Nebula Dashboard", category: "Web App", imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80", description: "AI-driven analytics platform.", link: "#" },
    { id: 2, title: "Orbit Commerce", category: "E-commerce", imageUrl: "https://images.unsplash.com/photo-1523206485973-6740a7563318?auto=format&fit=crop&w=800&q=80", description: "Next-gen shopping experience.", link: "#" },
    { id: 3, title: "Zenith Banking", category: "Fintech", imageUrl: "https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?auto=format&fit=crop&w=800&q=80", description: "Secure banking for the future.", link: "#" },
  ];

  return (
    <div className="bg-background min-h-screen text-white">
      <Navbar />
      
      <main className="pt-32 pb-20 container mx-auto px-4">
        <div className="text-center mb-20">
          <h1 className="font-display text-6xl md:text-8xl font-bold mb-6">Selected <span className="text-gradient">Works</span></h1>
          <p className="text-xl text-muted-foreground">Showcase of our finest digital craftsmanship.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {items.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group relative rounded-3xl overflow-hidden aspect-[4/3] cursor-pointer"
            >
              {/* Image with Parallax-like Zoom */}
              <div className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110" style={{ backgroundImage: `url(${item.imageUrl})` }} />
              
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 backdrop-blur-sm flex flex-col items-center justify-center text-center p-8">
                <span className="text-primary font-bold tracking-widest uppercase text-sm mb-2 translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-100">{item.category}</span>
                <h3 className="text-4xl font-display font-bold mb-4 translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-150">{item.title}</h3>
                <p className="text-white/80 max-w-md mb-6 translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-200">{item.description}</p>
                
                {item.link && (
                  <a href={item.link} target="_blank" rel="noopener noreferrer" className="translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-300">
                    <button className="flex items-center gap-2 px-6 py-3 rounded-full bg-white text-black font-bold hover:bg-primary hover:text-white transition-colors">
                      View Project <ExternalLink size={16} />
                    </button>
                  </a>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
