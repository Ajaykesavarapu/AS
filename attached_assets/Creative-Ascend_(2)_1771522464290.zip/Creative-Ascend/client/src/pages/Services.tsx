import { motion } from "framer-motion";
import { Link } from "wouter";
import { ArrowRight, Box, Monitor, PenTool, Database, Cloud, Smartphone } from "lucide-react";
import { useServices } from "@/hooks/use-services";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

// Fallback services if API is empty
const fallbackServices = [
  { id: 1, title: "Web Development", slug: "web-development", shortDescription: "High-performance web applications built with React and Node.", iconUrl: "web" },
  { id: 2, title: "Mobile Apps", slug: "mobile-apps", shortDescription: "Native and cross-platform mobile experiences.", iconUrl: "mobile" },
  { id: 3, title: "UI/UX Design", slug: "ui-ux-design", shortDescription: "User-centric design systems and interfaces.", iconUrl: "design" },
  { id: 4, title: "Cloud Solutions", slug: "cloud-solutions", shortDescription: "Scalable infrastructure on AWS and Azure.", iconUrl: "cloud" },
];

export default function Services() {
  const { data: services, isLoading } = useServices();
  const displayServices = services?.length ? services : fallbackServices;

  const getIcon = (url: string) => {
    // Check if it's a URL
    if (url.startsWith('http')) {
      return <img src={url} alt="Service Icon" className="w-full h-full object-cover rounded-xl" />;
    }

    switch(url) {
      case 'web': return <Monitor className="w-full h-full p-2" />;
      case 'design': return <PenTool className="w-full h-full p-2" />;
      case 'cloud': return <Cloud className="w-full h-full p-2" />;
      case 'mobile': return <Smartphone className="w-full h-full p-2" />;
      default: return <Box className="w-full h-full p-2" />;
    }
  };

  return (
    <div className="bg-background min-h-screen text-white">
      <Navbar />
      
      <main className="pt-32 pb-20 container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-24"
        >
          <h1 className="font-display text-6xl md:text-8xl font-bold mb-6">
            Our <span className="text-gradient">Services</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Comprehensive digital solutions designed to propel your business into the future.
          </p>
        </motion.div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((n) => (
              <div key={n} className="h-[400px] rounded-[2rem] bg-white/5 animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {displayServices.map((service, i) => (
              <Link key={service.id} href={`/services/${service.slug}`}>
                <motion.div
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ y: -10, scale: 1.02 }}
                  className="group relative h-[450px] bg-white/5 backdrop-blur-xl border border-white/10 rounded-[2rem] p-8 flex flex-col justify-between overflow-hidden cursor-pointer hover:border-primary/50 transition-all duration-500 shadow-2xl shadow-black/50"
                >
                  {/* Hover Gradient Background */}
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  
                  <div className="relative z-10">
                    <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-white/10 to-white/5 border border-white/20 flex items-center justify-center mb-8 group-hover:bg-primary group-hover:border-primary transition-all duration-300 shadow-lg">
                      <div className="text-white w-10 h-10">
                         {getIcon(service.iconUrl)}
                      </div>
                    </div>
                    <h3 className="text-3xl font-display font-bold mb-4">{service.title}</h3>
                    <p className="text-muted-foreground leading-relaxed group-hover:text-white/90 transition-colors">
                      {service.shortDescription}
                    </p>
                  </div>

                  <div className="relative z-10 flex items-center gap-3 text-primary font-bold group-hover:text-white transition-colors">
                    Explore Details
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform" />
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
