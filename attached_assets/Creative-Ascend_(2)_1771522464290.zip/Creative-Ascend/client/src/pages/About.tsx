import { motion } from "framer-motion";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Users, Target, Rocket } from "lucide-react";

export default function About() {
  return (
    <div className="bg-background min-h-screen text-white overflow-hidden">
      <Navbar />
      
      <main className="pt-32 pb-20 container mx-auto px-4">
        {/* Hero */}
        <div className="text-center mb-24 relative">
          <motion.div
             initial={{ opacity: 0, scale: 0.8 }}
             animate={{ opacity: 1, scale: 1 }}
             transition={{ duration: 0.8 }}
             className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-primary/10 to-secondary/10 rounded-full blur-[120px] pointer-events-none"
           />
           
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-display text-6xl md:text-8xl font-bold mb-8 relative z-10"
          >
            Who We <span className="text-gradient">Are</span>
          </motion.h1>
          <p className="text-2xl text-muted-foreground max-w-3xl mx-auto relative z-10 leading-relaxed">
            We are a collective of visionaries, engineers, and artists redefining the boundaries of the digital world.
          </p>
        </div>

        {/* Story Grid */}
        <div className="grid md:grid-cols-2 gap-12 items-center mb-32">
          <div className="space-y-6">
            <h2 className="text-4xl font-display font-bold">Our Philosophy</h2>
            <div className="w-16 h-1 bg-primary mb-6" />
            <p className="text-lg text-muted-foreground leading-loose">
              At Creative Ascend, we believe that technology should not just function; it should feel alive. We combine deep engineering expertise with artistic intuition to create products that resonate on an emotional level.
            </p>
            <p className="text-lg text-muted-foreground leading-loose">
              Our 3D-first approach isn't just aesthetic—it's about adding dimension to information, making complex systems intuitive and engaging.
            </p>
          </div>
          <div className="relative h-[400px] bg-white/5 rounded-[2rem] overflow-hidden border border-white/10 shadow-2xl">
            {/* Abstract 3D shape placeholder */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary via-background to-secondary opacity-20" />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-64 h-64 border-4 border-white/10 rounded-full animate-[spin_10s_linear_infinite]" />
              <div className="absolute w-48 h-48 border-4 border-primary/30 rounded-full animate-[spin_15s_linear_infinite_reverse]" />
            </div>
          </div>
        </div>

        {/* Values */}
        <div className="grid md:grid-cols-3 gap-8 mb-24">
          {[
            { icon: Users, title: "Collaborative Spirit", desc: "We work as an extension of your team." },
            { icon: Target, title: "Precision Focus", desc: "Every pixel and line of code matters." },
            { icon: Rocket, title: "Future Ready", desc: "Building for tomorrow's web standards." },
          ].map((item, i) => (
            <motion.div
              key={i}
              whileHover={{ y: -10 }}
              className="glass-card p-8 rounded-3xl text-center"
            >
              <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-6 text-primary">
                <item.icon size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4 font-display">{item.title}</h3>
              <p className="text-muted-foreground">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
