import { motion } from "framer-motion";
import { Link } from "wouter";
import { useBlogs } from "@/hooks/use-blogs";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Calendar } from "lucide-react";

export default function Blogs() {
  const { data: blogs } = useBlogs();
  
  // Fake data
  const posts = blogs?.length ? blogs : [
    { id: 1, title: "The Future of Web3 Design", slug: "web3-design", excerpt: "How decentralized tech is shaping UI patterns.", date: "Oct 12, 2024", author: "Alex Chen", coverImage: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=800&q=80" },
    { id: 2, title: "Mastering 3D Interactions", slug: "3d-interactions", excerpt: "Creating depth in flat interfaces.", date: "Sep 28, 2024", author: "Sarah Jones", coverImage: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80" },
    { id: 3, title: "React Server Components", slug: "rsc-guide", excerpt: "A deep dive into the new architecture.", date: "Sep 15, 2024", author: "Mike Ross", coverImage: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?auto=format&fit=crop&w=800&q=80" },
  ];

  return (
    <div className="bg-background min-h-screen text-white">
      <Navbar />
      
      <main className="pt-32 pb-20 container mx-auto px-4">
        <div className="text-center mb-20">
          <h1 className="font-display text-6xl md:text-8xl font-bold mb-6">Insights & <span className="text-gradient">Ideas</span></h1>
          <p className="text-xl text-muted-foreground">Thoughts on technology, design, and the digital frontier.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {posts.map((post, i) => (
            <Link key={post.id} href={`/blogs/${post.slug}`}>
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="group cursor-pointer"
              >
                <div className="rounded-2xl overflow-hidden mb-6 aspect-video border border-white/10 shadow-xl group-hover:shadow-primary/20 transition-all duration-500">
                  <div className="w-full h-full bg-cover bg-center group-hover:scale-105 transition-transform duration-700" style={{ backgroundImage: `url(${post.coverImage})` }} />
                </div>
                
                <div className="flex items-center gap-2 text-primary text-sm mb-3">
                  <Calendar size={14} />
                  <span>{new Date(post.date || Date.now()).toLocaleDateString()}</span>
                  <span className="text-white/30">•</span>
                  <span className="text-muted-foreground">{post.author}</span>
                </div>
                
                <h3 className="text-2xl font-display font-bold mb-3 group-hover:text-primary transition-colors">{post.title}</h3>
                {/* @ts-ignore */}
                <p className="text-muted-foreground line-clamp-2">{post.excerpt || "Read the full article to learn more about this topic."}</p>
              </motion.div>
            </Link>
          ))}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
