import { motion, useScroll, useTransform } from "framer-motion";
import { Link } from "wouter";
import { useRef } from "react";
import { ArrowRight, Code, Box, Layout, Smartphone, Layers, ShieldCheck } from "lucide-react";
import { useServices } from "@/hooks/use-services";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function Home() {
  const { scrollYProgress } = useScroll();
  const heroRef = useRef(null);
  const opacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.2], [1, 0.9]);
  const { data: services } = useServices();

  const features = [
    { icon: Layers, title: "Modern Architecture", desc: "Built on cutting-edge stacks" },
    { icon: ShieldCheck, title: "Enterprise Security", desc: "Bank-grade protection" },
    { icon: Smartphone, title: "Mobile First", desc: "Optimized for every device" },
  ];

  return (
    <div className="bg-background min-h-screen text-white overflow-hidden perspective-1000">
      <Navbar />
      
      {/* Hero Section */}
      <section ref={heroRef} className="relative h-screen flex items-center justify-center pt-20 overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 pointer-events-none">
           <motion.div 
             animate={{ rotate: 360 }}
             transition={{ duration: 50, repeat: Infinity, ease: "linear" }}
             className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-gradient-to-r from-primary/20 to-secondary/20 rounded-full blur-[120px]"
           />
           <motion.div 
             animate={{ rotate: -360 }}
             transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
             className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] bg-gradient-to-r from-accent/20 to-primary/20 rounded-full blur-[150px]"
           />
        </div>

        <motion.div 
          style={{ opacity, scale }}
          className="container relative z-10 text-center px-4"
        >
          <motion.h1 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="font-display text-6xl md:text-8xl lg:text-9xl font-bold tracking-tighter mb-6 bg-clip-text text-transparent bg-gradient-to-b from-white via-white to-white/50"
          >
            AS Kreativ
            <br />
            <span className="text-gradient">Dimensions</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="text-lg md:text-2xl text-muted-foreground max-w-2xl mx-auto mb-12 font-light leading-relaxed"
          >
            We craft immersive digital experiences that break the flat screen barrier. 
            Transform your brand into a dimensional reality.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4, duration: 0.5 }}
            className="flex flex-col sm:flex-row gap-6 justify-center items-center"
          >
            <Link href="/services">
              <button className="px-8 py-4 rounded-full bg-white text-background font-bold text-lg hover:bg-gray-200 transition-colors shadow-[0_0_40px_rgba(255,255,255,0.3)]">
                Explore Services
              </button>
            </Link>
            <Link href="/portfolio">
              <button className="px-8 py-4 rounded-full border border-white/20 hover:bg-white/5 text-white font-medium text-lg backdrop-blur-sm transition-all">
                View Work
              </button>
            </Link>
          </motion.div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div 
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/50"
        >
          <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-2">
            <div className="w-1 h-2 bg-white rounded-full" />
          </div>
        </motion.div>
      </section>

      {/* Features Grid */}
      <section className="py-32 relative z-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className="glass-card p-8 rounded-3xl hover:bg-white/10 transition-all duration-300 group"
              >
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <feature.icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-2xl font-bold mb-4 font-display">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 3D Services Preview */}
      <section className="py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent pointer-events-none" />
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-7xl font-bold font-display mb-6">Our Expertise</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Delivering future-ready solutions across the digital spectrum.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* If services exist, map them. Otherwise show placeholders */}
            {services?.slice(0, 3).map((service, i) => (
              <Link key={service.id} href={`/services/${service.slug}`}>
                <motion.div
                  whileHover={{ y: -10, rotateX: 5, rotateY: 5 }}
                  className="group relative h-[400px] rounded-[2rem] overflow-hidden cursor-pointer preserve-3d perspective-1000"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-md border border-white/10 transition-all duration-500 group-hover:border-primary/50" />
                  
                  <div className="absolute inset-0 p-8 flex flex-col justify-end z-20 bg-gradient-to-t from-black via-transparent to-transparent">
                    <div className="mb-4 w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 group-hover:bg-primary group-hover:border-primary transition-colors overflow-hidden">
                      {service.iconUrl.startsWith('http') ? (
                        <img src={service.iconUrl} alt={service.title} className="w-full h-full object-cover" />
                      ) : (
                        <Box className="w-8 h-8 text-white" />
                      )}
                    </div>
                    <h3 className="text-3xl font-bold mb-2 group-hover:text-primary transition-colors">{service.title}</h3>
                    <p className="text-white/70 line-clamp-2 mb-6">{service.shortDescription}</p>
                    <div className="flex items-center gap-2 text-primary font-medium group-hover:translate-x-2 transition-transform">
                      Learn More <ArrowRight size={16} />
                    </div>
                  </div>
                  
                  {/* Decorative Glow */}
                  <div className="absolute top-0 right-0 w-64 h-64 bg-primary/20 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/2 group-hover:bg-primary/30 transition-colors" />
                </motion.div>
              </Link>
            ))}
          </div>

          <div className="mt-16 text-center">
            <Link href="/services">
              <button className="px-8 py-3 rounded-full border border-white/20 hover:bg-white/10 transition-all text-white font-medium">
                View All Services
              </button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
