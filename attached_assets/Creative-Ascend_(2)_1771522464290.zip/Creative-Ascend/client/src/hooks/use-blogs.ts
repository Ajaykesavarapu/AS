import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";

export function useBlogs() {
  return useQuery({
    queryKey: [api.blogs.list.path],
    queryFn: async () => {
      const res = await fetch(api.blogs.list.path);
      if (!res.ok) throw new Error("Failed to fetch blogs");
      return api.blogs.list.responses[200].parse(await res.json());
    },
  });
}

export function useBlog(slug: string) {
  return useQuery({
    queryKey: [api.blogs.get.path, slug],
    queryFn: async () => {
      const url = buildUrl(api.blogs.get.path, { slug });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch blog");
      return api.blogs.get.responses[200].parse(await res.json());
    },
    enabled: !!slug,
  });
}
