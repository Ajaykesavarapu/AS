import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

// Services Table - supports the new detailed page requirements
export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  shortDescription: text("short_description").notNull(),
  iconUrl: text("icon_url").notNull(), // 3D icon URL or placeholder
  // Detailed page content fields
  fullDescription: text("full_description").notNull(), // "What is that service"
  whyThis: text("why_this").notNull(), // "Why this"
  keyBenefits: jsonb("key_benefits").notNull().$type<string[]>(), // Array of benefits
  useCases: jsonb("use_cases").notNull().$type<string[]>(), // Array of use cases
  ourApproach: text("our_approach").notNull(), // "Our approach"
  createdAt: timestamp("created_at").defaultNow(),
});

// Blogs Table
export const blogs = pgTable("blogs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  content: text("content").notNull(),
  coverImage: text("cover_image"),
  author: text("author").notNull(),
  publishedAt: timestamp("published_at").defaultNow(),
});

// Portfolio Table
export const portfolio = pgTable("portfolio", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  category: text("category").notNull(),
  link: text("link"),
});

// Contact Inquiries (for "Let's Talk" and Footer Contact)
export const inquiries = pgTable("inquiries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject"),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// === SCHEMAS ===
export const insertServiceSchema = createInsertSchema(services).omit({ id: true, createdAt: true });
export const insertBlogSchema = createInsertSchema(blogs).omit({ id: true, publishedAt: true });
export const insertPortfolioSchema = createInsertSchema(portfolio).omit({ id: true });
export const insertInquirySchema = createInsertSchema(inquiries).omit({ id: true, createdAt: true });

// === TYPES ===
export type Service = typeof services.$inferSelect;
export type InsertService = z.infer<typeof insertServiceSchema>;
export type Blog = typeof blogs.$inferSelect;
export type PortfolioItem = typeof portfolio.$inferSelect;
export type Inquiry = typeof inquiries.$inferSelect;
export type InsertInquiry = z.infer<typeof insertInquirySchema>;
