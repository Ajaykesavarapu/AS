import { z } from 'zod';
import { insertInquirySchema, services, blogs, portfolio } from './schema';

// ============================================
// API CONTRACT
// ============================================
export const api = {
  services: {
    list: {
      method: 'GET' as const,
      path: '/api/services' as const,
      responses: {
        200: z.array(z.custom<typeof services.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/services/:slug' as const,
      responses: {
        200: z.custom<typeof services.$inferSelect>(),
        404: z.object({ message: z.string() }),
      },
    },
  },
  blogs: {
    list: {
      method: 'GET' as const,
      path: '/api/blogs' as const,
      responses: {
        200: z.array(z.custom<typeof blogs.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/blogs/:slug' as const,
      responses: {
        200: z.custom<typeof blogs.$inferSelect>(),
        404: z.object({ message: z.string() }),
      },
    },
  },
  portfolio: {
    list: {
      method: 'GET' as const,
      path: '/api/portfolio' as const,
      responses: {
        200: z.array(z.custom<typeof portfolio.$inferSelect>()),
      },
    },
  },
  inquiries: {
    create: {
      method: 'POST' as const,
      path: '/api/inquiries' as const,
      input: insertInquirySchema,
      responses: {
        201: z.custom<typeof insertInquirySchema>(),
        400: z.object({ message: z.string() }),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
