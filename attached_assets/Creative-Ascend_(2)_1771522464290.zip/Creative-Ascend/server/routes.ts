import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { db } from "./db";
import { services, blogs, portfolio } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get(api.services.list.path, async (req, res) => {
    const allServices = await storage.getServices();
    res.json(allServices);
  });

  app.get(api.services.get.path, async (req, res) => {
    const service = await storage.getServiceBySlug(req.params.slug);
    if (!service) {
      return res.status(404).json({ message: 'Service not found' });
    }
    res.json(service);
  });

  app.get(api.blogs.list.path, async (req, res) => {
    const allBlogs = await storage.getBlogs();
    res.json(allBlogs);
  });

  app.get(api.blogs.get.path, async (req, res) => {
    const blog = await storage.getBlogBySlug(req.params.slug);
    if (!blog) {
      return res.status(404).json({ message: 'Blog post not found' });
    }
    res.json(blog);
  });

  app.get(api.portfolio.list.path, async (req, res) => {
    const items = await storage.getPortfolio();
    res.json(items);
  });

  app.post(api.inquiries.create.path, async (req, res) => {
    try {
      const input = api.inquiries.create.input.parse(req.body);
      const inquiry = await storage.createInquiry(input);
      res.status(201).json(inquiry);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existingServices = await storage.getServices();
  if (existingServices.length === 0) {
    console.log("Seeding AS Kreativ content with final services...");

    await db.insert(services).values([
      {
        title: "Digital Marketing",
        slug: "digital-marketing",
        shortDescription: "Strategic foundation-level services that drive all execution and ROI-focused growth.",
        iconUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2015&auto=format&fit=crop",
        fullDescription: "Improving visibility and organic traffic through SEO, SEM, SMM, and AI-driven strategies. We cover everything from strategy & planning to performance marketing and analytics.",
        whyThis: "Strategic digital marketing is the foundation of any successful business in the digital age. It ensures your brand reaches the right audience with the right message.",
        keyBenefits: ["Higher Organic Traffic", "ROI-Focused Growth", "Brand Visibility", "Data-Driven Insights"],
        useCases: ["E-commerce Growth", "Lead Generation", "Brand Awareness", "Market Dominance"],
        ourApproach: "Strategy & Planning, Performance Frameworks, Funnel Mapping, and Continuous Optimization using real-time data."
      },
      {
        title: "Web Development",
        slug: "website-development",
        shortDescription: "Custom engineering of responsive, performance-focused digital assets and SaaS solutions.",
        iconUrl: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?q=80&w=2070&auto=format&fit=crop",
        fullDescription: "End-to-end web engineering covering strategy, design, frontend, backend, and long-term maintenance. We build corporate sites, e-commerce platforms, and custom SaaS products.",
        whyThis: "Your website is your most valuable digital asset. We build it to be fast, secure, and optimized for conversions and growth.",
        keyBenefits: ["Custom Scalable Code", "Responsive UI/UX", "Secure Infrastructure", "SEO Technical Optimization"],
        useCases: ["Corporate Portals", "SaaS Platforms", "E-commerce Stores", "Custom Web Apps"],
        ourApproach: "Discovery, Design, Engineering, Deployment, and Growth Optimization focusing on performance and user experience."
      },
      {
        title: "Automation",
        slug: "automation",
        shortDescription: "Reducing manual work and enabling scalable digital operations through AI and workflow orchestration.",
        iconUrl: "https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=2070&auto=format&fit=crop",
        fullDescription: "Streamlining business processes, marketing, and sales through intelligent AI agents and integrations. We specialize in workflow design and AI-powered decision intelligence.",
        whyThis: "Automation allows you to scale your business efficiency without scaling your workload or overhead.",
        keyBenefits: ["Workforce Efficiency", "Scalable Operations", "Error Reduction", "Enhanced Customer Experience"],
        useCases: ["Business Process Automation", "Marketing Workflows", "Sales Pipeline Automation", "AI Customer Support"],
        ourApproach: "Workflow Design, Integration, AI Implementation, and Performance Monitoring to ensure seamless operations."
      },
      {
        title: "Graphic Design",
        slug: "graphic-design",
        shortDescription: "Visual storytelling through brand identity, UI/UX design, and motion graphics.",
        iconUrl: "https://images.unsplash.com/photo-1626785774573-4b799314346d?q=80&w=2070&auto=format&fit=crop",
        fullDescription: "Industry-standard visual creation spanning branding, digital execution, and high-engagement motion graphics for brands and creators.",
        whyThis: "Strong visual identity establishes trust and governs how a brand looks and feels across all digital and physical touchpoints.",
        keyBenefits: ["Strong Brand Identity", "High-Engagement Visuals", "User-Centric Design", "Creative Differentiation"],
        useCases: ["Brand Refresh", "Marketing Collateral", "UI/UX Prototyping", "Motion Graphics"],
        ourApproach: "Brand Governance, Creative Strategy, Prototyping, and Visual Execution focused on brand consistency."
      }
    ]);

    await db.insert(blogs).values([
      {
        title: "The Future of Web Design in 2026",
        slug: "future-web-design-2026",
        content: "3D interactions and AI-driven personalization are taking center stage in the next evolution of the web...",
        author: "AS Kreativ",
        coverImage: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop"
      }
    ]);

    await db.insert(portfolio).values([
      {
        title: "Global Enterprise Portal",
        description: "A large-scale digital ecosystem for a global client built with modern tech.",
        imageUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2670&auto=format&fit=crop",
        category: "Web Development"
      }
    ]);

    console.log("AS Kreativ Database seeded with final services successfully!");
  }
}
